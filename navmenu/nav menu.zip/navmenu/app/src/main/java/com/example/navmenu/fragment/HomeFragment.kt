package com.example.navmenu.fragment

import androidx.fragment.app.Fragment
import com.example.navmenu.R

class HomeFragment:Fragment(R.layout.fragment_home) {
}