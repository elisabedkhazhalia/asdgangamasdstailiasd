package com.example.navmenu.fragment

import androidx.fragment.app.Fragment
import com.example.navmenu.R

class SettingsFragment : Fragment(R.layout.fragment_settings) {
}
